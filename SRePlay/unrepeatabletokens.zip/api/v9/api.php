<?php

session_start();

//header("Content-Type: application/json");

// Create a new CSRF token.
if (! isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = base64_encode(openssl_random_pseudo_bytes(32));
}

function genToken(){
	$_SESSION['csrf_token'] = base64_encode(openssl_random_pseudo_bytes(32));
	return $_SESSION['csrf_token'];
}

if (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
    // POST data is valid.
	
	$q = '';
	
	if(isset($_POST['q']) && !empty($_POST['q'])){
		$q = $_POST['q'];
	}
	
	$data = 'Select car';
	
	switch($q){
		case "volvo":
			$data = 'Volvo revolvo';
			break;
		case "saab":
			$data = 'Saab besaab';
			break;
		case "mercedes":
			$data = 'Mercedes ease';
			break;
		case "audi":
			$data = 'Audi body';
			break;
	}
	
	$res = array("success"=>true, "data"=>$data, "token"=>genToken());

} else {
	$res = array("success"=>false, "data"=>"Invalid Token", "token"=>genToken());
}

echo json_encode($res);

?>